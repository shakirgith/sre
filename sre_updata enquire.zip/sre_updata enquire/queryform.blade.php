@extends('layouts.master')
@section('meta_title', 'About us Page')
@section('contents')
<style>
    .iti {width: 100%;}
    input#phone {padding-right:1.5rem }
</style>
<div class="page-heading"><h1>GET IN TOUCH WITH US</h1></div>   
<section class="get-in-touch-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title mb-0">
                    <h4 class="m-0 text-uppercase font-weight-bold">My Form Query</h4>
                </div>
               
                    @if(session()->has('msg'))
                        <div class="alert alert-success">
                        {{session()->get('msg')}}
                        </div>
                        @endif


                        {{-- @if ($message = Session::get('success'))
                        <div class="alert alert-success">
                            <strong>{{ $message }}</strong>
                        </div>
                      @endif
                      @if (count($errors) > 0)
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                  <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                      @endif --}}

                <form action="{{route('FormQuery')}}" method="POST" enctype="multipart/form-data">
                    @csrf

                 
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <select class="form-select form-control" name="gender" aria-label="Default select example" value="{{old('gender')}}">
                                    <option value="-1" selected>Select Title</option>
                                    <option value="Mr">Mr</option>
                                    <option value="Mrs">Mrs</option>
                                    <option value="Miss">Miss</option>
                              </select>
                              @error('gender')
                              <span class="text-danger">{{ $message }}</span>
                              @enderror
                            </div>
                        </div>


                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="text" class="form-control p-4" name="name"  placeholder="Your Full Name" value="{{old('name')}}" />
                                @error('name')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="text" class="form-control pt-4 pb-4" name="phone" id="phone"  value="{{old('phone')}}" />
                                @error('phone')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="email" class="form-control p-4" name="email" placeholder="Your Email" value="{{old('email')}}" />
                                @error('email')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <select class="form-select form-control" name="country" id="country" aria-label="Default select example" value="{{old('country')}}">
                                    <option selected>Select Country</option>
                                    @if(!empty($countries))
                                        @foreach ($countries as $country) 
                                        <option value="{{$country->name}}">{{$country->name}}</option>
                                        @endforeach 
                                    @endif
                                </select>

                              @error('country')
                              <span class="text-danger">{{ $message }}</span>
                              @enderror
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <select class="form-select form-control" name="state" id="state" aria-label="Default select example" value="{{old('state')}}">
                                    <option selected>Select State</option>
                                     @if(!empty($states))
                                         @foreach ($states as $state)
                                         <option {{ ($user->state == $state->name) ? 'selected' : '' }} value="{{ $state->name }}">{{ $state->name }}</option>
                                         @endforeach
                                     @endif
                                </select>

                              @error('state')
                              <span class="text-danger">{{ $message }}</span>
                              @enderror
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <select class="form-select form-control" id="city" name="city" aria-label="Default select example" value="{{old('city')}}">
                                    <option selected>Select City</option>
                                     @if (!empty($cities))
                                         @foreach ($cities as $city)
                                         <option {{ ($user->city == $city->name) ? 'selected' : '' }} value="{{ $city->name }}">{{ $city->name }}</option>
                                        @endforeach
                                      @endif
                                </select>

                              @error('city')
                              <span class="text-danger">{{ $message }}</span>
                              @enderror
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <select class="form-select form-control" name="service" aria-label="Default select example" value="{{old('services')}}">
                                    <option value="-1" selected>Select Services</option>
                                    <option value="php">PHP</option>
                                    <option value="react">Website Development</option>
                              </select>
                              @error('services')
                              <span class="text-danger">{{ $message }}</span>
                              @enderror
                            </div>
                        </div>


                      
                   
                    <div class="col-md-6">
                        <div class="form-group">
                        <input class="form-control" type="file" name="userfile" id="fileChoose" />
                        <figcaption class="blockquote-footer">Maximum upload size: 2 MB</figcaption>
                        @error('userfile')
                        <span class="text-danger">{{ $message }}</span>
                        @enderror 
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                        <textarea class="form-control" rows="4" name="desc" placeholder="Message" value="{{old('desc')}}"></textarea>
                        @error('desc')
                        <span class="text-danger">{{ $message }}</span>
                        @enderror
                        </div>
                    </div>

                </div>
                
                    <div>
                        <button class="btn btn-primary font-weight-semi-bold px-4" style="height: 50px;"
                            type="submit">Request</button>
                    </div>
                </form>
                
            </div>
            
        </div>
    </div>
</div>
<!-- Contact End -->



</section>

@endsection

@section('js')
<script type="text/javascript">


    $(document).ready(function(){
     $.ajaxSetup({
          headers: {
             'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
          }
    });
         $("#country").change(function(){
             var country_id = $(this).val();
 
             if (country_id == "") {
                 var country_id = 0;
             } 
 
             $.ajax({
                 url: '{{ url("/fetch-states/") }}/'+country_id,
                 type: 'get',
                 dataType: 'json',
                 success: function(response) {                 
                     $('#state').find('option:not(:first)').remove();
                     $('#city').find('option:not(:first)').remove();
 
                     if (response['states'].length > 0) {
                         $.each(response['states'], function(key,value){
                             $("#state").append("<option value='"+value['name']+"'>"+value['name']+"</option>")
                         });
                     } 
                 }
             });            
         });
 
 
         $("#state").change(function(){
             var state_id = $(this).val();
 
             console.log(state_id);
 
             if (state_id == "") {
                 var state_id = 0;
             } 
 
             $.ajax({
                 url: '{{ url("/fetch-cities/") }}/'+state_id,
                 type: 'get',
                 dataType: 'json',
                 success: function(response) {                    
                     $('#city').find('option:not(:first)').remove();
 
                     if (response['cities'].length > 0) {
                         $.each(response['cities'], function(key,value){
                             $("#city").append("<option value='"+value['name']+"'>"+value['name']+"</option>")
                         });
                     } 
                 }
             });            
         });
 
    });
 
 </script>


 <!-- start javascript library phone code directories  -->
<link rel="stylesheet" href="https://cdn.tutorialjinni.com/intl-tel-input/17.0.19/css/intlTelInput.css"/>
<script src="https://cdn.tutorialjinni.com/intl-tel-input/17.0.19/js/intlTelInput.min.js"></script>

<script>
    var input = document.querySelector("#phone");
window.intlTelInput(input, {
  separateDialCode: true
});
</script>
<!-- end javascript -->

@endsection





























<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;
use App\Http\Controllers\ContactsController;
use App\Http\Controllers\QueryformController;
// use App\Http\Controllers\FileUpload;



Route::controller(PageController::class)->group (function(){

    Route::get('/', 'showHome')->name('home');
    Route::get('/aboutus', 'showAboutus')->name('about');
    // Route::get('/contactus', 'showContactus')->name('contactus');
    Route::get('/privacy', 'policyPrivacy')->name('privacy');

    // without group
    // Route::get('/user_info', [PageController::class, 'showUsers'])->name('users');

});


Route::get('/contactus', [ContactsController::class, 'contactPage']);
Route::post('/contactus', [ContactsController::class, 'addContacts'])->name('contactus');

Route::get('/queryform', [QueryformController::class, 'quertIndex']);
Route::get('/fetch-states/{id}', [QueryformController::class, 'getStates'])->name('state');
Route::get('/fetch-cities/{id}', [QueryformController::class, 'getCities'])->name('city');

Route::post('/queryform', [QueryformController::class, 'dataStore'])->name('FormQuery');






// Route::get('/', function () {
//     return view('welcome');
// });


Route::fallback(function(){
    return view('notfound');
})->name('404_error_page');